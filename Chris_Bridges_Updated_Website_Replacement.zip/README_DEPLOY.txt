Chris Bridges Portfolio — Deployment Package

This folder is ready to replace the files in the root of your current GitHub Pages website repository.

Deployment:
1. Back up your current website repository.
2. Delete/replace the existing website files in the repository root.
3. Upload ALL files and folders from this package, preserving the folder structure.
4. Keep the included CNAME file if you use the same custom domain.
5. Commit/push the changes.
6. GitHub Pages should rebuild automatically.

The assets folder is required. Do not upload index.html by itself.
